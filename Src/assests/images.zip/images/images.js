export default {
  title: require('./download1.png'),
  case1: require('./Grp1.png'),
  case2: require('./Grp4.png'),
  case3: require('./Grp5.png'),
  vector1: require('./Grp2.png'),
  vector2: require('./Grp3.png'),
  vector3: require('./Vector.png'),
  upload1: require('./upload1.png'),
  upload2: require('./upload2.png'),
  upload3: require('./upload3.png'),
  // ... add more images here
};
